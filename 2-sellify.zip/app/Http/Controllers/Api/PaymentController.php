<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Company;
use App\Models\Package;
use App\Models\Subscription;
use Carbon\Carbon;
use Stripe\StripeClient;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    /**
     * Create a payment session (Stripe Checkout example)
     * Body:
     * {
     *   company_id: int,
     *   package_id: int,
     *   success_url: string (optional),
     *   cancel_url: string (optional)
     * }
     */
    public function createSession(Request $request)
    {
        $data = $request->validate([
            'company_id' => 'required|exists:companies,id',
            'package_id' => 'required|exists:packages,id',
            'success_url' => 'nullable|url',
            'cancel_url' => 'nullable|url',
        ]);

        $company = Company::findOrFail($data['company_id']);
        $package = Package::findOrFail($data['package_id']);

        if ((float)$package->price <= 0) {
            return response()->json(['message' => 'Package is free. No payment needed.'], 400);
        }

        // تأكد من وجود STRIPE_SECRET في env
        $stripeSecret = env('STRIPE_SECRET');
        if (!$stripeSecret) {
            return response()->json(['message' => 'Stripe secret not configured.'], 500);
        }

        $stripe = new StripeClient($stripeSecret);

        $successUrl = $data['success_url'] ?? url('/payment/success?session_id={CHECKOUT_SESSION_ID}');
        $cancelUrl = $data['cancel_url'] ?? url('/payment/cancel');

        // إنشاء جلسة Checkout
        try {
            $session = $stripe->checkout->sessions->create([
                'payment_method_types' => ['card'],
                'mode' => 'payment',
                'line_items' => [[
                    'price_data' => [
                        'currency' => 'usd', // عدّل العملة لو لازم
                        'product_data' => [
                            'name' => $package->name,
                        ],
                        'unit_amount' => (int)round($package->price * 100),
                    ],
                    'quantity' => 1,
                ]],
                'client_reference_id' => $company->id,
                'metadata' => [
                    'company_id' => $company->id,
                    'package_id' => $package->id
                ],
                'success_url' => $successUrl,
                'cancel_url' => $cancelUrl,
            ]);

            return response()->json([
                'checkout_url' => $session->url,
                'session_id' => $session->id,
            ]);
        } catch (\Exception $e) {
            Log::error('Stripe create session error: '.$e->getMessage());
            return response()->json(['message' => 'Failed to create payment session', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Webhook handler for Stripe (or other provider)
     * Configure provider to call this URL.
     */
    public function webhook(Request $request)
    {
        $payload = $request->getContent();
        $sigHeader = $request->header('Stripe-Signature');
        $endpointSecret = env('STRIPE_WEBHOOK_SECRET');

        try {
            // verify signature - recommended
            if ($endpointSecret) {
                $stripe = new \Stripe\StripeClient(env('STRIPE_SECRET'));
                $event = \Stripe\Webhook::constructEvent($payload, $sigHeader, $endpointSecret);
            } else {
                // no signature configured -> parse body
                $event = json_decode($payload, true);
            }

            $type = $event['type'] ?? ($event->type ?? null);

            // handle checkout.session.completed
            if ($type === 'checkout.session.completed' || ($event['type'] ?? '') === 'checkout.session.completed') {
                $session = $event['data']['object'] ?? $event->data->object;
                $companyId = $session['metadata']['company_id'] ?? null;
                $packageId = $session['metadata']['package_id'] ?? null;
                $providerSubscriptionId = $session['id'] ?? null;

                if ($companyId && $packageId) {
                    // activate subscription: find pending subscription for company & package
                    $sub = Subscription::where('company_id', $companyId)
                        ->where('package_id', $packageId)
                        ->where('status', 'pending')
                        ->latest()
                        ->first();

                    $starts = Carbon::now();
                    // duration from package or default 30
                    $package = Package::find($packageId);
                    $days = $package->duration_days ?? 30;
                    $ends = Carbon::now()->addDays($days);

                    if ($sub) {
                        $sub->update([
                            'starts_at' => $starts,
                            'ends_at' => $ends,
                            'status' => 'active',
                            'provider' => 'stripe',
                            'provider_subscription_id' => $providerSubscriptionId,
                        ]);
                    } else {
                        $sub = Subscription::create([
                            'company_id' => $companyId,
                            'package_id' => $packageId,
                            'starts_at' => $starts,
                            'ends_at' => $ends,
                            'status' => 'active',
                            'provider' => 'stripe',
                            'provider_subscription_id' => $providerSubscriptionId,
                        ]);
                    }

                    // update company
                    $company = Company::find($companyId);
                    if ($company) {
                        $company->update([
                            'package_id' => $packageId,
                            'subscription_ends_at' => $ends,
                            'is_active' => 1,
                        ]);
                    }
                }
            }

            return response()->json(['received' => true], 200);
        } catch (\UnexpectedValueException $e) {
            // invalid payload
            return response()->json(['message' => 'Invalid payload'], 400);
        } catch (\Exception $e) {
            \Log::error('Webhook error: '.$e->getMessage());
            return response()->json(['message' => 'Webhook error', 'error' => $e->getMessage()], 500);
        }
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Package;
use App\Models\Subscription;
use App\Models\Company;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class SubscriptionController extends Controller
{
    /**
     * إنشاء اشتراك جديد
     */
    public function store(Request $request)
    {
        $request->validate([
            'package_id'     => 'required|exists:packages,id',
            'auto_renew'     => 'boolean',
            'payment_method' => 'nullable|string',
        ]);

        $user = $request->user();
        $company = $user->company;

        if (!$company) {
            return response()->json(['message' => 'User has no company.'], 422);
        }

        $package = Package::findOrFail($request->package_id);

        DB::beginTransaction();
        try {
            if ((float)$package->price <= 0) {
                // باقة مجانية → تفعيل مباشر
                $starts = now();
                $ends   = now()->addDays($package->duration_days ?? 30);

                $sub = Subscription::create([
                    'company_id' => $company->id,
                    'package_id' => $package->id,
                    'starts_at'  => $starts,
                    'ends_at'    => $ends,
                    'status'     => 1, // active
                    'auto_renew' => $request->auto_renew ? 1 : 0,
                ]);

                $company->update([
                    'package_id'             => $package->id,
                    'subscription_ends_at'   => $ends,
                    'is_active'              => 1,
                ]);

                DB::commit();
                return response()->json($sub, 201);
            }

            // باقة مدفوعة → Pending + تجهيز الدفع
            $sub = Subscription::create([
                'company_id' => $company->id,
                'package_id' => $package->id,
                'status'     => 0, // pending
                'auto_renew' => $request->auto_renew ? 1 : 0,
            ]);

            DB::commit();
            return response()->json([
                'message'         => 'Subscription created. Proceed to payment.',
                'subscription_id' => $sub->id,
                'payment_url'     => url('/api/payments/create')
            ], 202);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Failed',
                'error'   => $e->getMessage()
            ], 500);
        }
    }

    /**
     * عرض الاشتراك الحالي للمستخدم
     */
    public function currentByAuth(Request $request)
    {
        return $this->getCurrentSubscription($request->user()->company->id ?? null);
    }

    /**
     * عرض الاشتراك الحالي برقم الشركة
     */
    public function currentByCompanyId($company_id)
    {
        return $this->getCurrentSubscription($company_id);
    }

    /**
     * تفعيل الاشتراك بعد الدفع
     */
    public function activate(Request $request)
    {
        $request->validate([
            'company_id' => 'required|exists:companies,id',
            'package_id' => 'required|exists:packages,id'
        ]);

        $company = Company::findOrFail($request->company_id);
        $package = Package::findOrFail($request->package_id);

        $starts = now();
        $ends   = now()->addDays($package->duration_days ?? 30);

        $subscription = Subscription::updateOrCreate(
            ['company_id' => $company->id, 'package_id' => $package->id],
            ['starts_at' => $starts, 'ends_at' => $ends, 'status' => 1]
        );

        $company->update([
            'package_id'           => $package->id,
            'subscription_ends_at' => $ends,
            'is_active'            => 1,
        ]);

        return response()->json([
            'message'      => 'Subscription activated successfully.',
            'subscription' => $subscription
        ]);
    }

    /**
     * تجديد الاشتراك
     */
    public function renew(Request $request)
    {
        $request->validate([
            'company_id' => 'required|exists:companies,id',
        ]);

        $company = Company::findOrFail($request->company_id);
        $subscription = Subscription::where('company_id', $company->id)
            ->orderBy('ends_at', 'desc')
            ->first();

        if (!$subscription) {
            return response()->json(['message' => 'No active subscription found'], 404);
        }

        $ends = Carbon::parse($subscription->ends_at)->addDays($subscription->package->duration_days ?? 30);
        $subscription->update(['ends_at' => $ends]);
        $company->update(['subscription_ends_at' => $ends]);

        return response()->json([
            'message'      => 'Subscription renewed successfully',
            'subscription' => $subscription
        ]);
    }

    /**
     * إلغاء الاشتراك
     */
    public function cancel(Request $request)
    {
        $request->validate([
            'company_id' => 'required|exists:companies,id',
        ]);

        $subscription = Subscription::where('company_id', $request->company_id)
            ->orderBy('ends_at', 'desc')
            ->first();

        if (!$subscription) {
            return response()->json(['message' => 'No subscription found'], 404);
        }

        $subscription->update(['status' => 0]);
        $subscription->company->update(['is_active' => 0]);

        return response()->json(['message' => 'Subscription cancelled successfully']);
    }

    /**
     * عرض تاريخ الاشتراكات
     */
    public function history($company_id)
    {
        $subscriptions = Subscription::with('package')
            ->where('company_id', $company_id)
            ->orderBy('starts_at', 'desc')
            ->get();

        return response()->json($subscriptions);
    }

    /**
     * دالة خاصة لإرجاع الاشتراك الحالي
     */
    private function getCurrentSubscription($company_id)
    {
        if (!$company_id) {
            return response()->json(['message' => 'No company ID provided'], 422);
        }

        $subscription = Subscription::with('package')
            ->where('company_id', $company_id)
            ->orderBy('ends_at', 'desc')
            ->first();

        if (!$subscription) {
            return response()->json(['message' => 'No subscription found'], 404);
        }

        return response()->json([
            'package'       => $subscription->package->name,
            'status'        => $subscription->status ? 'active' : 'pending',
            'starts_at'     => $subscription->starts_at,
            'ends_at'       => $subscription->ends_at,
            'duration_days' => $subscription->package->duration_days
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    /**
     * تسجيل الدخول
     */
    public function login(Request $request)
    {
        // التحقق من البيانات
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);

        // محاولة تسجيل الدخول
        if (!Auth::attempt($request->only('email', 'password'))) {
            return response()->json([
                'message' => 'Invalid credentials'
            ], 401);
        }

        $user = Auth::user();

        // جلب الشركة المرتبطة بالمستخدم
        $company = $user->company ?? null;

        // إنشاء توكن لو حابب تستخدمه مع الـ API
        // (يشتغل لو فعّلت sanctum)
        // $token = $user->createToken('api_token')->plainTextToken;

        return response()->json([
            'message' => 'Login successful',
            'user'    => $user,
            'company' => $company,
            // 'token'   => $token // شيل التعليق لو محتاج توكن
        ]);
    }
}

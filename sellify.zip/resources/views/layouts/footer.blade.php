  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      للتواصل 01030889618
    </div>
    <div class=" d-none d-sm-inline">
        V.1.0.1
    </div>
    <!-- Default to the left -->
    <a href="tel: +201030889618">تصميم وبرمجة ستوب جروب للبرمجيات</a>. جميع الحقوق محفوظة &copy; 2026 </strong> 
  </footer>
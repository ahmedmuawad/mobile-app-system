<?php use Illuminate\Database\Migrations\Migration;
class CreateWalletTransactionsTable extends Migration { public function up() {} }
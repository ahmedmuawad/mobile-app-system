<?php return array (
  'infyomlabs/laravel-ui-adminlte' => 
  array (
    'providers' => 
    array (
      0 => 'InfyOm\\AdminLTEPreset\\AdminLTEPresetServiceProvider',
    ),
  ),
  'jeroennoten/laravel-adminlte' => 
  array (
    'providers' => 
    array (
      0 => 'JeroenNoten\\LaravelAdminLte\\AdminLteServiceProvider',
    ),
  ),
  'laravel-lang/actions' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Actions\\ServiceProvider',
    ),
  ),
  'laravel-lang/attributes' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Attributes\\ServiceProvider',
    ),
  ),
  'laravel-lang/config' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Config\\ServiceProvider',
    ),
  ),
  'laravel-lang/http-statuses' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\HttpStatuses\\ServiceProvider',
    ),
  ),
  'laravel-lang/lang' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Lang\\ServiceProvider',
    ),
  ),
  'laravel-lang/locales' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Locales\\ServiceProvider',
    ),
  ),
  'laravel-lang/models' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Models\\ServiceProvider',
    ),
  ),
  'laravel-lang/moonshine' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\MoonShine\\ServiceProvider',
    ),
  ),
  'laravel-lang/publisher' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Publisher\\ServiceProvider',
    ),
  ),
  'laravel-lang/routes' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\Routes\\ServiceProvider',
    ),
  ),
  'laravel-lang/starter-kits' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelLang\\StarterKits\\ServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
  ),
);
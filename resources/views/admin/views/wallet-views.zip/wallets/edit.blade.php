@extends('layouts.app')
@section('content')
<h1>Edit Wallet</h1>
<form method="POST" action="{{ route('admin.wallets.update', $wallet) }}">
    @csrf @method('PUT')
    <input type="text" name="number" value="{{ $wallet->number }}">
    <select name="wallet_provider_id">
        @foreach($providers as $provider)
            <option value="{{ $provider->id }}" {{ $wallet->wallet_provider_id == $provider->id ? 'selected' : '' }}>{{ $provider->name }}</option>
        @endforeach
    </select>
    <input type="text" name="owner_name" value="{{ $wallet->owner_name }}">
    <button type="submit">Update</button>
</form>
@endsection
@extends('layouts.app')
@section('content')
<h1>Wallets</h1>
<a href="{{ route('admin.wallets.create') }}">Add Wallet</a>
<table>
    <thead><tr><th>Number</th><th>Owner</th><th>Provider</th><th>Actions</th></tr></thead>
    <tbody>
        @foreach($wallets as $wallet)
            <tr>
                <td>{{ $wallet->number }}</td>
                <td>{{ $wallet->owner_name }}</td>
                <td>{{ $wallet->provider->name }}</td>
                <td>
                    <a href="{{ route('admin.wallets.edit', $wallet) }}">Edit</a>
                    <form action="{{ route('admin.wallets.destroy', $wallet) }}" method="POST" style="display:inline-block">
                        @csrf @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
@endsection
@extends('layouts.app')
@section('content')
<h1>Create Wallet</h1>
<form method="POST" action="{{ route('admin.wallets.store') }}">
    @csrf
    <input type="text" name="number" placeholder="Wallet Number">
    <select name="wallet_provider_id">
        @foreach($providers as $provider)
            <option value="{{ $provider->id }}">{{ $provider->name }}</option>
        @endforeach
    </select>
    <input type="text" name="owner_name" placeholder="Owner Name">
    <button type="submit">Save</button>
</form>
@endsection
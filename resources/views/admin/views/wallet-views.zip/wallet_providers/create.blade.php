@extends('layouts.app')
@section('content')
<h1>Create Wallet Provider</h1>
<form method="POST" action="{{ route('admin.wallet_providers.store') }}">
    @csrf
    <input type="text" name="name" placeholder="Name">
    <input type="number" name="daily_limit" placeholder="Daily Limit">
    <input type="number" name="monthly_limit" placeholder="Monthly Limit">
    <button type="submit">Save</button>
</form>
@endsection
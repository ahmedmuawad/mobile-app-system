@extends('layouts.app')
@section('content')
<h1>Wallet Providers</h1>
<a href="{{ route('admin.wallet_providers.create') }}">Add Provider</a>
<table>
    <thead><tr><th>Name</th><th>Daily Limit</th><th>Monthly Limit</th><th>Actions</th></tr></thead>
    <tbody>
        @foreach($providers as $provider)
            <tr>
                <td>{{ $provider->name }}</td> 
                <td>{{ $provider->daily_limit }}</td>
                <td>{{ $provider->monthly_limit }}</td>
                <td>
                    <a href="{{ route('admin.wallet_providers.edit', $provider) }}">Edit</a>
                    <form action="{{ route('admin.wallet_providers.destroy', $provider) }}" method="POST" style="display:inline-block">
                        @csrf @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
@endsection
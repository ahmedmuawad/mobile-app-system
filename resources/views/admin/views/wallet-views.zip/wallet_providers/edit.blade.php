@extends('layouts.app')
@section('content')
<h1>Edit Wallet Provider</h1>
<form method="POST" action="{{ route('admin.wallet_providers.update', $walletProvider) }}">
    @csrf @method('PUT')
    <input type="text" name="name" value="{{ $walletProvider->name }}">
    <input type="number" name="daily_limit" value="{{ $walletProvider->daily_limit }}">
    <input type="number" name="monthly_limit" value="{{ $walletProvider->monthly_limit }}">
    <button type="submit">Update</button>
</form>
@endsection
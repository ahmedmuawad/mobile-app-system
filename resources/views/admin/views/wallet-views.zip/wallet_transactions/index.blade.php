@extends('layouts.app')
@section('content')
<h1>Wallet Transactions</h1>
<a href="{{ route('admin.wallet_transactions.create') }}">Add Transaction</a>
<table>
    <thead><tr><th>Wallet</th><th>Type</th><th>Amount</th><th>Commission</th><th>To</th><th>Note</th><th>Actions</th></tr></thead>
    <tbody>
        @foreach($transactions as $t)
            <tr>
                <td>{{ $t->wallet->number }} ({{ $t->wallet->provider->name }})</td>
                <td>{{ ucfirst($t->type) }}</td>
                <td>{{ $t->amount }}</td>
                <td>{{ $t->commission }}</td>
                <td>{{ $t->target_number }}</td>
                <td>{{ $t->note }}</td>
                <td>
                    <a href="{{ route('admin.wallet_transactions.edit', $t) }}">Edit</a>
                    <form action="{{ route('admin.wallet_transactions.destroy', $t) }}" method="POST" style="display:inline-block">
                        @csrf @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </tbody>
</table>
@endsection